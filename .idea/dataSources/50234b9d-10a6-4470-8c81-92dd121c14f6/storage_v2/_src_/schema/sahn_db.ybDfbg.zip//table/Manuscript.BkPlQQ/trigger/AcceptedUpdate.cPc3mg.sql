create definer = sahn@`%` trigger AcceptedUpdate
	before UPDATE
	on Manuscript
	for each row
BEGIN
		IF NEW.man_status = "accepted" THEN 
			SET NEW.man_status = "typesetting";
		END IF;
	END;

