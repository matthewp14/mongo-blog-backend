create definer = sahn@`%` view AnyAuthorManuscripts as
select concat(`sahn_db`.`Author`.`fname`, ' ', `sahn_db`.`Author`.`lname`) AS `name`,
	   `sahn_db`.`Authorship`.`author_id`                                  AS `author_id`,
	   `sahn_db`.`Manuscript`.`title`                                      AS `title`
from ((`sahn_db`.`Author` join `sahn_db`.`Authorship` on (`sahn_db`.`Authorship`.`author_id` = `sahn_db`.`Author`.`id`))
		 join `sahn_db`.`Manuscript` on (`sahn_db`.`Authorship`.`manuscript_id` = `sahn_db`.`Manuscript`.`id`))
order by `sahn_db`.`Author`.`lname`, `sahn_db`.`Manuscript`.`status_last_updated`;

