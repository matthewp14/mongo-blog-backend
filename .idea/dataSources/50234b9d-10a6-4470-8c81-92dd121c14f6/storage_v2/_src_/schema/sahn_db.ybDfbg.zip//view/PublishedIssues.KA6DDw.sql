create definer = sahn@`%` view PublishedIssues as
select `sahn_db`.`Manuscript`.`title` AS `title`, `sahn_db`.`Manuscript`.`pages` AS `pages`
from ((`sahn_db`.`Journal` join `sahn_db`.`Accepted` on (`sahn_db`.`Journal`.`journal_id` = `sahn_db`.`Accepted`.`journal_id`))
		 join `sahn_db`.`Manuscript` on (`sahn_db`.`Accepted`.`manuscript_id` = `sahn_db`.`Manuscript`.`id`))
where `sahn_db`.`Journal`.`published_date` is not null
order by `sahn_db`.`Journal`.`journal_year`, `sahn_db`.`Journal`.`journal_num`, `sahn_db`.`Accepted`.`start_page`;

