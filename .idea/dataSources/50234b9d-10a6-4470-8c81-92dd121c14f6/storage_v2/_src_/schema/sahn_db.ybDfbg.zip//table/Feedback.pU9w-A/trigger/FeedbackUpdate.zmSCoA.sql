create definer = sahn@`%` trigger FeedbackUpdate
	before UPDATE
	on Feedback
	for each row
BEGIN
        SET NEW.recommendation_date = CURDATE();
    END;

