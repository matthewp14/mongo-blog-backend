create definer = sahn@`%` view LeadAuthorManuscripts as
select `sahn_db`.`Author`.`lname`             AS `lname`,
	   `sahn_db`.`Authorship`.`author_id`     AS `author_id`,
	   `sahn_db`.`Authorship`.`manuscript_id` AS `manuscript_id`
from ((`sahn_db`.`Author` join `sahn_db`.`Authorship` on (`sahn_db`.`Authorship`.`author_id` = `sahn_db`.`Author`.`id`))
		 join `sahn_db`.`Manuscript` on (`sahn_db`.`Authorship`.`manuscript_id` = `sahn_db`.`Manuscript`.`id`))
where `sahn_db`.`Authorship`.`author_order` = 1
order by `sahn_db`.`Author`.`lname`, `sahn_db`.`Authorship`.`author_id`, `sahn_db`.`Manuscript`.`status_last_updated`;

