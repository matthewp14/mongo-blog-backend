create definer = sahn@`%` trigger NoReviewerICode
	before INSERT
	on Manuscript
	for each row
BEGIN
		DECLARE signal_message VARCHAR(128);
        IF NEW.ICode_id NOT IN (SELECT  ICode_id FROM Reviewer_ICode) THEN
			SET signal_message = CONCAT("No reviewers with the specified ICode: ", CAST(NEW.ICode_id AS CHAR), " currently exist. This manuscript cannot be reviewed at the moment.");
            SET NEW.man_status = "rejected";
			SIGNAL SQLSTATE '01000' SET message_text = signal_message;
		END IF;
	END;

