create
	definer = sahn@`%` function ViewRevId() returns int
BEGIN
		RETURN @rev_id;
	END;

