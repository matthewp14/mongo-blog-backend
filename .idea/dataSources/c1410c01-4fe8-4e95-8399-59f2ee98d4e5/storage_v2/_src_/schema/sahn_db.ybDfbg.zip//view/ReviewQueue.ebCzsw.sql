create definer = sahn@`%` view ReviewQueue as
select concat(`sahn_db`.`Author`.`fname`, ' ', `sahn_db`.`Author`.`lname`)         AS `primary_author_name`,
	   `sahn_db`.`Authorship`.`author_id`                                          AS `author_id`,
	   `sahn_db`.`Manuscript`.`id`                                                 AS `id`,
	   group_concat((select concat(`sahn_db`.`Reviewer`.`fname`, ' ', `sahn_db`.`Reviewer`.`lname`) AS `reviewer_name`
					 from ((`sahn_db`.`Reviewer` join `sahn_db`.`Feedback` on (`sahn_db`.`Feedback`.`reviewer_id` = `sahn_db`.`Reviewer`.`id`))
							  join `sahn_db`.`Manuscript`
								   on (`sahn_db`.`Manuscript`.`id` = `sahn_db`.`Feedback`.`manuscript_id`))
					 where `sahn_db`.`Manuscript`.`id` = `sahn_db`.`Authorship`.`manuscript_id`
					 group by `sahn_db`.`Feedback`.`manuscript_id`) separator ',') AS `reviewer_names`
from ((`sahn_db`.`Manuscript` join `sahn_db`.`Authorship` on (`sahn_db`.`Manuscript`.`id` = `sahn_db`.`Authorship`.`manuscript_id`))
		 join `sahn_db`.`Author` on (`sahn_db`.`Authorship`.`author_id` = `sahn_db`.`Author`.`id`))
where `sahn_db`.`Manuscript`.`man_status` = 'under review'
  and `sahn_db`.`Authorship`.`author_order` = 1
order by `sahn_db`.`Manuscript`.`status_last_updated`;

