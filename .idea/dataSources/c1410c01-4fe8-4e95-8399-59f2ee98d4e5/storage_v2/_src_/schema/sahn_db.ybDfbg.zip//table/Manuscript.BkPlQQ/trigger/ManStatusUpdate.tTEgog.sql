create definer = sahn@`%` trigger ManStatusUpdate
	before UPDATE
	on Manuscript
	for each row
BEGIN
        SET NEW.status_last_updated = CURDATE();
    END;

