create definer = sahn@`%` view ReviewStatus as
select `sahn_db`.`Feedback`.`assigned_at`    AS `assigned_at`,
	   `sahn_db`.`Feedback`.`manuscript_id`  AS `manuscript_id`,
	   `sahn_db`.`Manuscript`.`title`        AS `title`,
	   `sahn_db`.`Feedback`.`A_score`        AS `A_score`,
	   `sahn_db`.`Feedback`.`C_score`        AS `C_score`,
	   `sahn_db`.`Feedback`.`M_score`        AS `M_score`,
	   `sahn_db`.`Feedback`.`E_score`        AS `E_score`,
	   `sahn_db`.`Feedback`.`recommendation` AS `recommendation`
from ((`sahn_db`.`Reviewer` join `sahn_db`.`Feedback` on (`sahn_db`.`Feedback`.`reviewer_id` = `sahn_db`.`Reviewer`.`id`))
		 join `sahn_db`.`Manuscript` on (`sahn_db`.`Manuscript`.`id` = `sahn_db`.`Feedback`.`manuscript_id`))
where `sahn_db`.`Feedback`.`reviewer_id` = `ViewRevId`()
order by `sahn_db`.`Feedback`.`recommendation_date`;

