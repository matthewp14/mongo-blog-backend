create definer = sahn@`%` trigger ReviewerDied
	before DELETE
	on Reviewer
	for each row
BEGIN
        UPDATE Manuscript
            SET man_status = 'received'
        WHERE Manuscript.id IN (
            -- any manuscript in “UnderReview” state for which that reviewer was the only reviewer
            SELECT id
            FROM Manuscript
                JOIN Feedback
                    ON Manuscript.id = Feedback.manuscript_id
            WHERE reviewer_id = OLD.id
              AND man_status = 'under review'
              AND (SELECT COUNT(*)
              FROM Feedback
              WHERE manuscript_id = Manuscript.id) = 1
			);

		-- any manuscript that doesn't have any more authors for that ICode is rejected
        UPDATE Manuscript
            SET man_status = 'rejected'
        WHERE (
            SELECT COUNT(*)
            FROM Reviewer_ICode
            WHERE Reviewer_ICode.ICode_id = Manuscript.ICode_id
			) = 1;
	END;

