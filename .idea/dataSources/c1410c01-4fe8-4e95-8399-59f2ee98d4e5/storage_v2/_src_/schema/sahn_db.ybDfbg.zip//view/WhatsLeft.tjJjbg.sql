create definer = sahn@`%` view WhatsLeft as
select `sahn_db`.`Manuscript`.`id`                  AS `id`,
	   `sahn_db`.`Manuscript`.`man_status`          AS `man_status`,
	   `sahn_db`.`Manuscript`.`status_last_updated` AS `status_last_updated`
from `sahn_db`.`Manuscript`;

